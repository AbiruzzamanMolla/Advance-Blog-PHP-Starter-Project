## Prepare Statement

1. Adding prepare statment in category.php
2. Added in add_category function in functions.php
3. Added in update_category in functions
4.

### User Feauters

1. username
2. First name
3. last name
4. gander
5. email
6. password

### User Profile

- Profile Photo
- Username
- First Name
- LAst name
- Gander
- Birthday
- City
- Country
- About me
- Number
- email
- facebook
- twitter
- Medium
- instragrum
- site address
- Reg date
- Last login
- Rights
