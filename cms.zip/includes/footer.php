<!-- Footer -->
<footer>
<div class="w3-center w3-small w3-opacity">
W3Schools is optimized for learning, testing, and training. Examples might be simplified to improve reading and basic understanding.
Tutorials, references, and examples are constantly reviewed to avoid errors, but we cannot warrant full correctness of all content.
While using this site, you agree to have read and accepted our <a href="about_copyright.html">terms of use</a>,
<a href="about_privacy.html">cookie and privacy policy</a>.
<a href="about_copyright.html">Copyright 1999-<?php echo date('Y'); ?></a> by Refsnes Data. All Rights Reserved.<br>
 <a href="index.php">Powered by Abir</a>.<br><br>
<a href="../index.html">
<img style="width:150px;height:28px;border:0" src="../images/w3schoolscom_gray.gif" alt="Simple CMS"></a>
</div>
<!-- jQuery -->
<script src="js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</body>

</html>
