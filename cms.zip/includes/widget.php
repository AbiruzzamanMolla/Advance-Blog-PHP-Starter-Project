<div class="well">
    <div class='panel text-center'>
        <p>Social Networks</p>
        <a href='http://facebook.com/asliabir'><span><i class='fa fa-fw fa-facebook-square'></i></span></a> | <a href='http://twitter.com/asliabir'><span><i class='fa fa-fw fa-twitter-square'></i></span></a> | <a href='http://medium.com/asliabir'><span><i class='fa fa-fw fa-medium'></i></span></a> | <a href='http://instagram.com/asliabir><span><i class='fa fa-fw fa-instagram'></i></span></a>
    </div>
</div>
